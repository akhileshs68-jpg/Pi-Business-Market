import { initializeApp } from 'firebase/app';
import { getFirestore, collection, getDocs, initializeFirestore } from 'firebase/firestore';
import * as fs from 'fs';

const configData = JSON.parse(fs.readFileSync('firebase-applet-config.json', 'utf8'));

const config = {
  apiKey: configData.apiKey,
  authDomain: configData.authDomain,
  projectId: configData.projectId,
  storageBucket: configData.storageBucket,
  messagingSenderId: configData.messagingSenderId,
  appId: configData.appId,
};

const app = initializeApp(config);
const db = initializeFirestore(app, { experimentalForceLongPolling: true }, configData.firestoreDatabaseId);

async function check() {
  const b = await getDocs(collection(db, 'businesses'));
  console.log("Total Businesses:", b.docs.length);
  b.docs.forEach(d => console.log('BIZ:', d.id, JSON.stringify(d.data())));
  
  const s = await getDocs(collection(db, 'stores'));
  console.log("Total Stores:", s.docs.length);
  s.docs.forEach(d => console.log('STORE:', d.id, JSON.stringify(d.data())));
  
  const p = await getDocs(collection(db, 'products'));
  console.log("Total Products:", p.docs.length);
  p.docs.forEach(d => console.log('PROD:', d.id, JSON.stringify(d.data())));
  
  process.exit(0);
}
check();
