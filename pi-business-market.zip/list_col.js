import { initializeApp, applicationDefault } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';

initializeApp({
  projectId: process.env.VITE_FIREBASE_PROJECT_ID,
  credential: applicationDefault()
});

const db = getFirestore();

async function run() {
  try {
    const collections = await db.listCollections();
    for (const col of collections) {
      console.log('Collection:', col.id);
    }
  } catch(e) {
    console.error(e);
  }
}
run();
